﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        MySqlConnection sqlconnect;
        MySqlCommand sqlcommand;
        MySqlDataAdapter sqldataadapter;
        string sqlquery;
        DataTable team;
        DataTable team2;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            sqlconnect = new MySqlConnection("server=localhost;uid=student;pwd=isbmantap;database=premier_league");
            //sqlconnect.Open();
            //sqlconnect.Close();
            team = new DataTable(); 
            team2 = new DataTable();    
            sqlquery = "select team_name, team_id from team;";
            sqlcommand = new MySqlCommand(sqlquery, sqlconnect);
            sqldataadapter = new MySqlDataAdapter(sqlcommand);
            sqldataadapter.Fill(team);
            sqldataadapter.Fill(team2); 
            CB_team1.DataSource = team;
            CB_team2.DataSource = team2;
            CB_team1.DisplayMember = "team_name";
            CB_team1.ValueMember = "team_id";
            CB_team2.DisplayMember = "team_name";
            CB_team2.ValueMember = "team_id";

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void CB_team1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
