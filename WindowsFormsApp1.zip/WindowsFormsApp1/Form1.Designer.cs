﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CB_team1 = new System.Windows.Forms.ComboBox();
            this.CB_team2 = new System.Windows.Forms.ComboBox();
            this.VS = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button_check = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label_captainteam1 = new System.Windows.Forms.Label();
            this.label_managerteam1 = new System.Windows.Forms.Label();
            this.label_captainteam2 = new System.Windows.Forms.Label();
            this.label_managerteam2 = new System.Windows.Forms.Label();
            this.label_capacity = new System.Windows.Forms.Label();
            this.label_stadium = new System.Windows.Forms.Label();
            this.label_skor = new System.Windows.Forms.Label();
            this.label_tanggal = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // CB_team1
            // 
            this.CB_team1.FormattingEnabled = true;
            this.CB_team1.Location = new System.Drawing.Point(84, 68);
            this.CB_team1.Name = "CB_team1";
            this.CB_team1.Size = new System.Drawing.Size(404, 33);
            this.CB_team1.TabIndex = 0;
            this.CB_team1.SelectedIndexChanged += new System.EventHandler(this.CB_team1_SelectedIndexChanged);
            // 
            // CB_team2
            // 
            this.CB_team2.FormattingEnabled = true;
            this.CB_team2.Location = new System.Drawing.Point(1020, 68);
            this.CB_team2.Name = "CB_team2";
            this.CB_team2.Size = new System.Drawing.Size(483, 33);
            this.CB_team2.TabIndex = 1;
            // 
            // VS
            // 
            this.VS.AutoSize = true;
            this.VS.Location = new System.Drawing.Point(748, 76);
            this.VS.Name = "VS";
            this.VS.Size = new System.Drawing.Size(40, 25);
            this.VS.TabIndex = 2;
            this.VS.Text = "VS";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(84, 679);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 82;
            this.dataGridView1.RowTemplate.Height = 33;
            this.dataGridView1.Size = new System.Drawing.Size(1590, 566);
            this.dataGridView1.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(79, 169);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 25);
            this.label1.TabIndex = 4;
            this.label1.Text = "Manager:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(79, 228);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 25);
            this.label2.TabIndex = 5;
            this.label2.Text = "Captain:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1015, 228);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 25);
            this.label3.TabIndex = 7;
            this.label3.Text = "Captain:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(1015, 169);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 25);
            this.label4.TabIndex = 6;
            this.label4.Text = "Manager:";
            // 
            // button_check
            // 
            this.button_check.Location = new System.Drawing.Point(708, 422);
            this.button_check.Name = "button_check";
            this.button_check.Size = new System.Drawing.Size(121, 49);
            this.button_check.TabIndex = 8;
            this.button_check.Text = "Check";
            this.button_check.UseVisualStyleBackColor = true;
            this.button_check.Click += new System.EventHandler(this.button1_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(534, 337);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(102, 25);
            this.label5.TabIndex = 10;
            this.label5.Text = "Capacity:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(534, 278);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(96, 25);
            this.label6.TabIndex = 9;
            this.label6.Text = "Stadium:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(534, 568);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 25);
            this.label7.TabIndex = 12;
            this.label7.Text = "Skor:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(534, 509);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(96, 25);
            this.label8.TabIndex = 11;
            this.label8.Text = "Tanggal:";
            // 
            // label_captainteam1
            // 
            this.label_captainteam1.AutoSize = true;
            this.label_captainteam1.Location = new System.Drawing.Point(209, 228);
            this.label_captainteam1.Name = "label_captainteam1";
            this.label_captainteam1.Size = new System.Drawing.Size(19, 25);
            this.label_captainteam1.TabIndex = 14;
            this.label_captainteam1.Text = "-";
            // 
            // label_managerteam1
            // 
            this.label_managerteam1.AutoSize = true;
            this.label_managerteam1.Location = new System.Drawing.Point(209, 169);
            this.label_managerteam1.Name = "label_managerteam1";
            this.label_managerteam1.Size = new System.Drawing.Size(19, 25);
            this.label_managerteam1.TabIndex = 13;
            this.label_managerteam1.Text = "-";
            // 
            // label_captainteam2
            // 
            this.label_captainteam2.AutoSize = true;
            this.label_captainteam2.Location = new System.Drawing.Point(1134, 228);
            this.label_captainteam2.Name = "label_captainteam2";
            this.label_captainteam2.Size = new System.Drawing.Size(19, 25);
            this.label_captainteam2.TabIndex = 16;
            this.label_captainteam2.Text = "-";
            // 
            // label_managerteam2
            // 
            this.label_managerteam2.AutoSize = true;
            this.label_managerteam2.Location = new System.Drawing.Point(1134, 169);
            this.label_managerteam2.Name = "label_managerteam2";
            this.label_managerteam2.Size = new System.Drawing.Size(19, 25);
            this.label_managerteam2.TabIndex = 15;
            this.label_managerteam2.Text = "-";
            // 
            // label_capacity
            // 
            this.label_capacity.AutoSize = true;
            this.label_capacity.Location = new System.Drawing.Point(664, 337);
            this.label_capacity.Name = "label_capacity";
            this.label_capacity.Size = new System.Drawing.Size(19, 25);
            this.label_capacity.TabIndex = 18;
            this.label_capacity.Text = "-";
            // 
            // label_stadium
            // 
            this.label_stadium.AutoSize = true;
            this.label_stadium.Location = new System.Drawing.Point(664, 278);
            this.label_stadium.Name = "label_stadium";
            this.label_stadium.Size = new System.Drawing.Size(19, 25);
            this.label_stadium.TabIndex = 17;
            this.label_stadium.Text = "-";
            // 
            // label_skor
            // 
            this.label_skor.AutoSize = true;
            this.label_skor.Location = new System.Drawing.Point(664, 568);
            this.label_skor.Name = "label_skor";
            this.label_skor.Size = new System.Drawing.Size(19, 25);
            this.label_skor.TabIndex = 20;
            this.label_skor.Text = "-";
            // 
            // label_tanggal
            // 
            this.label_tanggal.AutoSize = true;
            this.label_tanggal.Location = new System.Drawing.Point(664, 509);
            this.label_tanggal.Name = "label_tanggal";
            this.label_tanggal.Size = new System.Drawing.Size(19, 25);
            this.label_tanggal.TabIndex = 19;
            this.label_tanggal.Text = "-";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2401, 1299);
            this.Controls.Add(this.label_skor);
            this.Controls.Add(this.label_tanggal);
            this.Controls.Add(this.label_capacity);
            this.Controls.Add(this.label_stadium);
            this.Controls.Add(this.label_captainteam2);
            this.Controls.Add(this.label_managerteam2);
            this.Controls.Add(this.label_captainteam1);
            this.Controls.Add(this.label_managerteam1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.button_check);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.VS);
            this.Controls.Add(this.CB_team2);
            this.Controls.Add(this.CB_team1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox CB_team1;
        private System.Windows.Forms.ComboBox CB_team2;
        private System.Windows.Forms.Label VS;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button_check;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label_captainteam1;
        private System.Windows.Forms.Label label_managerteam1;
        private System.Windows.Forms.Label label_captainteam2;
        private System.Windows.Forms.Label label_managerteam2;
        private System.Windows.Forms.Label label_capacity;
        private System.Windows.Forms.Label label_stadium;
        private System.Windows.Forms.Label label_skor;
        private System.Windows.Forms.Label label_tanggal;
    }
}

